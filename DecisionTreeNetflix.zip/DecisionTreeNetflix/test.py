import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt
from sklearn.tree import plot_tree
import matplotlib.patches as mpatches

# Chargement et nettoyage des données
df = pd.read_csv("netflix_titles.csv")

# Suppression des lignes contenant des valeurs manquantes dans le dataset
df = df.dropna()

# Encodage des variables catégorielles (comme les pays, les évaluations et les réalisateurs)
encoder = LabelEncoder()

# Encodage des colonnes 'country', 'rating', 'director'
df['country'] = encoder.fit_transform(df['country'])
df['rating'] = encoder.fit_transform(df['rating'])
df['director'] = encoder.fit_transform(df['director'])

# Transformation de la colonne 'duration' pour extraire les minutes comme valeur entière
df['duration'] = df['duration'].apply(lambda x: int(x.split()[0]) if isinstance(x, str) else x)

# Vérification rapide des transformations
print(df.head())

# Définir les caractéristiques (X) et la cible (y) pour l'arbre de décision
X = df[['duration', 'country', 'rating', 'release_year']]
y = df['type']

# Diviser les données en ensembles d'entraînement et de test (80% pour l'entraînement, 20% pour le test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Création du modèle d'arbre de décision avec une profondeur maximale de 5
clf = DecisionTreeClassifier(max_depth=5, random_state=42)
clf.fit(X_train, y_train)

# Tracé de l'arbre de décision avec une personnalisation automatique des couleurs
plt.figure(figsize=(15, 10))  # Taille de la figure

# Tracer l'arbre de décision
tree_plot = plot_tree(
    clf,
    feature_names=X.columns,  # Afficher les noms des caractéristiques
    class_names=["Movie", "TV Show"],  # Nom des classes
    filled=True,  # Remplir les noeuds avec des couleurs distinctes
    rounded=True,  # Bordures arrondies pour plus de clarté
    proportion=True,  # Afficher les proportions des classes
    fontsize=12  # Taille de la police
)

# Personnalisation manuelle de la couleur des noeuds
ax = plt.gca()  # Obtenir l'axe du graphique
for i, patch in enumerate(ax.get_children()):
    if isinstance(patch, mpatches.FancyBboxPatch):
        # Récupérer le texte associé au noeud
        node_text = ax.texts[i].get_text()

        # Personnalisation des couleurs : changer selon la classe
        if "TV Show" in node_text:  # Si c'est un "TV Show"
            patch.set_facecolor("#e50914")  # Rouge Netflix pour "TV Show"
        elif "Movie" in node_text:  # Si c'est un "Movie"
            patch.set_facecolor("#000000")  # Noir pour "Movie"
        else:
            patch.set_facecolor("#c9c9c9")  # Gris pour les autres noeuds

# Ajouter un titre en rouge et en gras
plt.title("Arbre de Décision - Prédiction du Type de Contenu Netflix", fontsize=16, fontweight='bold', color='red')

# Affichage du graphique
plt.show()

# Évaluation du modèle
accuracy = clf.score(X_test, y_test)
print(f"Précision du modèle sur les données de test : {accuracy:.2f}")
